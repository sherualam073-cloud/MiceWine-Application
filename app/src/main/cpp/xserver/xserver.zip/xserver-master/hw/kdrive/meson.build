subdir('src')
subdir('ephyr')
